# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 3736dfa6824f4ae9ad115b7314d64eec
- Android key alias: QHJvaGl0dmVybWEuZGV2MjkvZHVuZGVyLW1pZmZsaW5haXJl
- Android key password: 4684306308a747758ba30878ed210c2c
      